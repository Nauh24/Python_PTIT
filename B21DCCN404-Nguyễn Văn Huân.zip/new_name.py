def new_name():

    print("Hello")