
package kiemtra;

import java.util.ArrayList;
import java.util.Scanner;

class SoNguyen {

    private ArrayList<Integer> a;

    public SoNguyen() {
        a=new ArrayList<>();
    }

    public SoNguyen(ArrayList<Integer> a) {
        this.a = a;
    }
   
    public void input() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhap day so nguyen:");
        String s = sc.nextLine();
        String[] tmp = s.split("\\s+");
        a.clear();
        for(String i : tmp){
            a.add(Integer.parseInt(i));
        }
               
    }

    public int findMin() {
        int minn = Integer.MAX_VALUE;
        for (int i : a) {
            if ( i < minn) {
                minn = i;
            }
        }
        return minn;
    }
    public int findMax(){
        int maxx = Integer.MIN_VALUE;
        for (int i : a) {
            if ( i > maxx) {
                maxx = i;
            }
        }
        return maxx;
    }
    
    public boolean tang(){
        for(int i=1;i<a.size();i++){
            if(a.get(i)<a.get(i-1)) return false;
        }
        return true;
    }
    public boolean giam(){
        for(int i=1;i<a.size();i++){
            if(a.get(i)>a.get(i-1)) return false;
        }
        return true;
    }
    public void soLanXuatHien(){
        int d[] = new int[10005];
        for(int i=0;i<a.size();i++){
            d[a.get(i)]++;
        }
        for(int i : d){
            System.out.println(i+" "+d[i]);
        }
    }
}
