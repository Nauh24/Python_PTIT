
package kiemtra;

import java.util.Scanner;

public class Xau {
    private String s;
    public void input(){
        Scanner sc =new Scanner(System.in);
        System.out.println("Nhap vao 1 xau: ");
        s =sc.nextLine();
        
    }
    public String chuanHoa(){
        String[] res=s.split("[|]+");
        String ans="";
        
        String[] tmp=res[0].toLowerCase().split("\\s+");
        for(String i : tmp){
            ans+=i.substring(0,1).toUpperCase()+i.substring(1)+" ";
        }
        return ans;
    }
    public void out(){
        String ans="";
        String[] res=s.split("[|]+");
     
        if(res[1]=="true"){
            ans+="Mr ";
        }
        else ans+="Miss ";
        ans+=chuanHoa();
        int tuoi=Integer.parseInt(res[2]);
        ans+=String.valueOf(2023-tuoi);
        System.out.println(ans);
    }
}
