package kiemtra;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
       Xau x =new Xau();
       SoNguyen sn =new SoNguyen();
        while (true){
            System.out.println("""
                1. Nhap vao 1 xau co dang: ho va ten |true hoac false| nam sinh 
                2.chuan hoa lai ho ten
                3.Nếu là true thì viết Mr, false thì Miss rồi họ tên chuẩn hóa, tuổi (năm hiện thời – năm sinh). Ví dụ Mr Tô An An, 21
                4.Nhập vào 1 dãy số nguyên
                5.Đưa ra số lớn nhất, bé nhất
                6.Đưa ra xem dãy số là gì? (tăng gần, giảm dần, hay lộn xôn)
                7.Đưa ra số lần xuất hiện của mỗi phần tử (không dùng Collections, Map)
                8.Nhập vào 1 đa thức Pn(x)
                9.Tính giá trị đạo hàm bậc 1 của đa thức tại xo=2 (P’(2))
                0.Thoat
                               """);
            int chon;
            Scanner sc =new Scanner(System.in);
            chon =sc.nextInt();
            switch (chon) {
                case 0->{
                    System.out.println("Bye");
                    System.exit(0);
                }
                case 1->{
                    x.input();
                }
                case 2->{
                    System.out.println(x.chuanHoa());
                }
                case 3->{
                    x.out();
                }
                case 4->{
                    sn.input();
                }
                case 5->{
                    System.out.println("So lon nhat: "+sn.findMax());
                    System.out.println("So be nhat: "+sn.findMin());
                }
                case 6->{
                    boolean ok1=sn.tang();
                    boolean ok2=sn.giam();
                    if(ok1==true) System.out.println("Day la day tang dan");
                    else if(ok2==true) System.out.println("Day la day giam dan");
                    else System.out.println("Day lon xon");
                }
                case 7->{
                    sn.soLanXuatHien();
                }
                case 8->{
                }
                case 9->{
                   
                            
                }
                default-> System.out.println("Moi nhap lai");
            }
        }
    }
}
